<script type="text/javascript">
   function HideAllButOne(id, className) 
   {
		var elements = document.getElementsByClassName(className);
	   
		for (var i = 0; i < elements.length; i++) 
		{
			if (elements[i].id == id)
			{
				elements[i].display = "block";
			}
			else
			{
				elements[i].display = "none";
			}
		}
   }
</script>